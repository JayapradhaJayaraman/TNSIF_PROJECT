export interface Employee {
    id?:number;
    name:string;
    role:string;
    email:string;
    phoneNumber:string;

}
